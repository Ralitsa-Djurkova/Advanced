﻿

using System.Collections.Generic;

namespace _09._PokemonTrainer
{
    public class Trainers
    {
        private string name;
        private int numberOfBadges;
        private List<Pokemon> pokemons;

        public Trainers(string name)
        {
            Name = name;
            NumberOfBadges = 0;
            Pokemons = new List<Pokemon>();
            
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
       
        public int NumberOfBadges
        {
            get { return numberOfBadges; }
            set { numberOfBadges = value; }
        }
       
        public List<Pokemon> Pokemons
        {
            get { return pokemons; }
            set { pokemons = value; }
        }



    }
}
